package sberprojectdirectory;


import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        InputOutput inputOutput = new InputOutput();
        ArrayList<City> cities = inputOutput.InputOutput();   //getting information from a file
        for (City city : cities) {
            System.out.println(city);
        }
    }
}